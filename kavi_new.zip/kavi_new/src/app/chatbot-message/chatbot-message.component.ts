// import { Component, OnInit } from '@angular/core';

// @Component({
//   selector: 'app-chatbot-message',
//   templateUrl: './chatbot-message.component.html',
//   styleUrls: ['./chatbot-message.component.css']
// })
// export class ChatbotMessageComponent implements OnInit {

//   messages=[];
//   flag;
//   class: string;
//   constructor() { }

//   ngOnInit() {
//     if(this.flag==1){
//       this.class="user";
//       // this.flag=0;
//     }else{
//       this.class="server"
//     }
//     // this.messages=["one","two","three"];
//         this.messages=[
//           {
//             name:"one",
//             class:"user"
//           },
//            {
//             name:"two",
//             class:"server"
//           },
//           {
//             name:"three",
//             class:"user"
//           }];
        
    
    
//   }

// }
