import { Injectable } from "@angular/core"
import { Http, Response } from "@angular/http";
import { Observable, Subscription, Subject } from "rxjs/Rx";

@Injectable()
export class PrototypeService{
    prototypes;
    prototypeSubscription:Subscription;
    prototypeSubject=new Subject<any>();
    errorMessage='';
    currFileName="";
    prototype;
    constructor(private http:Http){}
    loadPrototypes(fileName){
        this.currFileName=fileName;
        //return this.http.get('./assets/data/prototypes/'+fileName+'.json')
        this.prototypeSubscription = this.http.get('./assets/data/prototypes/chatbot.json')
        .map(
            (response: Response) =>{
             return response.json();
            }
        )
        .subscribe(
          (response) => {
            this.prototypes=response.prototypes;
            console.log(this.prototypes)
            this.prototypeSubject.next(this.prototypes.slice()) 
            console.log(this.prototypeSubject)      
          },
          (error)=>{
            this.errorMessage=error;
            console.log("Error : "+error)
          }
        )
    }
    

     getPrototype(id){ 
        if(this.prototypes){
          return this.prototypes.find(prototype => prototype.prototype_id === id);
        }else{
          return null;
        }              
           
     }

    
    private handleError(errorResponse: Response) {  
        console.log(errorResponse.statusText);  
        return Observable.throw(errorResponse.json().error || "Server error");  
    } 
}