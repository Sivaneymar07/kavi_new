import { Component, OnInit, Directive, ElementRef,Renderer} from '@angular/core';



@Component({
  selector: 'app-chatbot',
  templateUrl: './chatbot.component.html',
  styleUrls: ['./chatbot.component.css']
})
// @Directive({
//   selector : '[messageItem]'
// })
export class ChatbotComponent implements OnInit {
   public buttonText: string = 'A New Button';
   public changeText(): void{
    this.buttonText = 'Text Changed';
  }

str: string="";
htmlText: string;
messages=[];
flag = 1;
chat: string;
server: string;
user: string;
// class: string; 

sendMsg() {
   
  if (this.flag == 1) {
   this.buttonText = 'Hi, I am Amy from the ToyBox team . ';
   this.chat=this.server;
  this.flag = 0;
}else{
  
   this.buttonText =this.str;
   this.chat=this.user;
 }
 this.htmlText = this.htmlText + `<p>`+this.buttonText+`</p> `;
//  console.log(this.htmlText);
 }
  constructor() { 
}
ngOnInit() {
     
}
  
  }


