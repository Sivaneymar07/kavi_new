angular.module('ToyBox.libraryFactory',[])
.factory('libraryFactory',libraryFactory);
	function libraryFactory($http){		
		var obj = {};
		obj.selectedLibrary = {};
		obj.getLibraryData = function(){
			  return $http.get('../resources/json/libraryList.json');	
		 }

		obj.setLibrary = function(library){
			obj.selectedLibrary = library;
			return obj;
		}

		obj.getLibrary = function(){
			return obj.selectedLibrary;
		}
		return obj;
	}