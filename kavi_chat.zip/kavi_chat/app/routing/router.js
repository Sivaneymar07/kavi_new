angular.module('ToyBox.router',['ngRoute'])
    .config(function($routeProvider){
    $routeProvider
    .when('/', {
            templateUrl: 'partials/landing_page.html',
            controller: 'homeController'
        })
        .when('/home', {
            templateUrl: 'partials/landing_page.html',
            controller: 'homeController'
        })
        .when('/conceptBuilder',{
            templateUrl:'partials/conceptBuilder.html'
            
        })
		 .when('/service-form', {
            templateUrl: 'partials/service_req_form.html',
            controller: 'customerDataController'
        })
        .when('/servicerequest_home', {
            templateUrl: 'partials/servicerequest_home.html',
        })

        .when('/micro',{
			templateUrl : 'partials/microsite.html'
        })
        .when('/channel',{
			 templateUrl :'partials/chooseChannel.html'
             
		})
        .when('/temp',{
			templateUrl : 'template/micrositeTemp.html',
			controller : 'micrositeController'
			
 		})
        	.when('/natureOfWebsite',{
			templateUrl  :'partials/nature.html'
             
		})
        .when('/toybox',{
			templateUrl  :'partials/toybox.html',
			controller : 'toyboxController'
		})
		.when('/designLayout',{
			templateUrl  :'partials/designlayout.html'
            
		})
        .when('/ready',{
			templateUrl  :'partials/readyPage.html',
			controller : 'readyPageController'
			
		})
		.when('/servicebox_1',{
			templateUrl : 'partials/servicebox_1.html'
			
 		})
 		.when('/servicebox_2',{
			templateUrl : 'partials/servicebox_2.html'
			
 		})
 		.when('/servicebox_3',{
			templateUrl : 'partials/servicebox_3.html'
			
 		})
		.when('/servicebox_4',{
			templateUrl  :'partials/servicebox_4.html'
			
		})
		.when('/servicebox_5',{
			templateUrl  :'partials/servicebox_5.html'
			
		})
		.when('/Chatbot',{
			templateUrl  :'partials/chatbot.html'
		})
    
     .when('/library', {
    // .when('/', {
            templateUrl: 'partials/library_page.html',
            controller: 'libraryController'
        })
    .when('/prototype',{
    		templateUrl:'partials/prototype_details.html',
    		controller:'prototypeController'
    })
    //  .when('/repo',{
    // 		templateUrl:'partials/repo.html',
    // 		controller:'repoController'
    // })
    .otherwise({
    	redirectTo:'/'
    });
    });
