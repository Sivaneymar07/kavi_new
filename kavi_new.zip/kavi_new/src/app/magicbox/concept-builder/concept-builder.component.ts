import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-concept-builder',
  templateUrl: './concept-builder.component.html',
  styleUrls: ['./concept-builder.component.css']
})
export class ConceptBuilderComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
