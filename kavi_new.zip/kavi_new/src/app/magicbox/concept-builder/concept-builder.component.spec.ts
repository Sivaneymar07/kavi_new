import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ConceptBuilderComponent } from './concept-builder.component';

describe('ConceptBuilderComponent', () => {
  let component: ConceptBuilderComponent;
  let fixture: ComponentFixture<ConceptBuilderComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ConceptBuilderComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ConceptBuilderComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
