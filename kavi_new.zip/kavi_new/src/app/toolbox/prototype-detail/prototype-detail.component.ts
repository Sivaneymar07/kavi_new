import { Component, OnInit, Input, ChangeDetectorRef, ChangeDetectionStrategy  } from '@angular/core';
import { Subscription } from 'rxjs/Rx';

import { PrototypeService } from '../../shared/prototype.service';
import { ActivatedRoute, Router, Params } from "@angular/router";
@Component({
  selector: 'app-prototype-detail',
  templateUrl: './prototype-detail.component.html',
  styleUrls: ['./prototype-detail.component.css'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class PrototypeDetailComponent implements OnInit {  
   
  prototypeId="";
  prototype={};
  
  constructor(private prototypeService: PrototypeService, private route:ActivatedRoute, private router:Router) {}
  ngOnInit() {

      this.route.params.subscribe( 
      (params: Params) => {
        this.prototypeId = params['prototypeId'];          
        this.prototype = this.prototypeService.getPrototype(this.prototypeId);
        console.log("@constructor"+this.prototype)         
         console.log(this.prototypeId)   
          

      });
     
      
  }

  backToPrototypeList(){
    this.router.navigate(['../'], {relativeTo:this.route})
  }

}
