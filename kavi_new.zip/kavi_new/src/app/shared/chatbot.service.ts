import { Injectable } from '@angular/core';
import { Http, Response } from "@angular/http";
import { Observable } from "rxjs/Rx";

@Injectable()
export class ChatbotService {
  constructor(private http:Http){}
    sendMsg(): Observable<any>{
        return this.http.get("https://api.api.ai/v1/query?v=20150910")
        .map(
            (response: Response) =>{
                
             return response.json();
            }
        ).catch(this.handleError)
    }

    private handleError(errorResponse: Response) {  
        console.log(errorResponse.statusText);  
        return Observable.throw(errorResponse.json().error || "Server error");  
    } 

}