angular.module('ToyBox.customerDataController',['ui.bootstrap'])
                    .controller("customerDataController",customerDataController);

                               function customerDataController($rootScope,$scope){
            $rootScope.customer_data = {}
                               $scope.getData = function(){
                $rootScope.customer_data.cust_name = $('#customerName').val();
                $rootScope.customer_data.poc = $('#poc').val();
                $rootScope.customer_data.domain = $('#domain').val();
                $rootScope.customer_data.email_address = $('#emailAddress').val();
                $rootScope.customer_data.problem_statement = $('#problemStatement').val();
                $rootScope.customer_data.tech_details = $('#tech_details').val();
                $scope.array=[]
                // $rootScope.customer_data.lf = $('lf').val();
                // console.log($rootScope.customer_data.lf)
                // if($('#check_lf').attr('checked')==true) {
                //             $rootScope.customer_data.lf = $('#lf').val();
                //         console.log("asdaads")
                //     } else if($('#check_mf').attr('checked')==true) 
                //     {
                //             $rootScope.customer_data.mf = $('#mf').val();
                //     }
                //     else  if($('#check_hf').attr('checked')==true) {
                //             $rootScope.customer_data.hf = $('#hf').val();
                //     }
                //     else  if($('#check_d').attr('checked')==true) {
                //             $rootScope.customer_data.d = $('#d').val();
                //     }
               
                        if ($('#lf').is(":checked"))
{
$rootScope.customer_data.details1= $("#lf").val();
} 
if ($('#mf').is(":checked"))
{
$rootScope.customer_data.details2= $("#mf").val();
} 
if ($('#hf').is(":checked"))
{
$rootScope.customer_data.details3= $("#hf").val();
} 
if ($('#d').is(":checked"))
{
$rootScope.customer_data.details4= $("#d").val();
} 
// $(document).ready(function () {
//     $('.nav li a').click(function(e) {

//         $('.nav li.active').removeClass('active');

//         var $parent = $(this).parent();
//         $parent.addClass('active');
//         e.preventDefault();
//     });
// });
                console.log($rootScope.customer_data);
              }
                             $scope.activeclass = function(i){
                                                  console.log('dascdsc')
                // $scope.a="tab";
                $('#tab'+i).removeClass('active');
                i++;
                $('#tab'+i).addClass('active');
                if(i==5){
                    
                     $('#tab3').removeClass('active');
                      $('#tab1').addClass('active');
                }

                               }

//          $scope.displayid = function(){        
             
//          var result = [];
// for (var l in $rootScope.customer_data) {
//   if ($rootScope.customer_data.hasOwnProperty(l)){
//     result.push(l+': '+$rootScope.customer_data[l]);
//   }
// }
//     result.push("Service_Request :"+"REQTB0000"+Math.floor(100000 + Math.random() * 900000) );
// alert(result.join('\n'));


 			
//  		}
 $scope.myVar = false;
 $scope.req_id=Math.floor(100000 + Math.random() * 900000);
    $scope.toggle = function() {

        $scope.myVar = !$scope.myVar;
    }; 


                          }
