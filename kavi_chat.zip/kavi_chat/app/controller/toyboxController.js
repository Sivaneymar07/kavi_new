
angular.module('ToyBox.toyboxController',[])
.controller("toyboxController", toyboxController);

function toyboxController($scope, $location, $rootScope, $anchorScroll,$http) {
    $scope.MessageType = "#fdd500";
    $scope.defaultColor = $scope.MessageType ;
    $scope.IsVisible = false;
    var currTheme= 0;
    $scope.selected=-1;
    $scope.themes = [
    {theme: 'theme1', id:0,active:false,imgLink:'one.png'},
    {theme: 'theme2', id:1,active:false,imgLink:'one.png'},
    {theme: 'theme3', id:2,active:false,imgLink:'one.png'},
    {theme: 'theme4', id:3,active:false,imgLink:'one.png'},
    {theme: 'theme5', id:4,active:false,imgLink:'one.png'},
    {theme: 'theme6', id:5,active:false,imgLink:'one.png'}
  ]; 
    $scope.store = function() {
        console.log($scope.titleName);
        localStorage.setItem('title', $scope.titleName);
        
        console.log($scope.titleName);
    }
    $http.get("json/theme.json")
    .then(function(response) {
        $scope.themes = response.data;
    }, function(response) {
        $scope.themes = "Something went wrong";
    });

    $scope.ShowHide = function() {
        //If DIV is visible it will be hidden and vice versa.
        $scope.IsVisible = $scope.IsVisible ? false : true;
    }
   $scope.changeTheme = function(sel, index) {
        console.log(sel)
        console.log($scope.themes[sel].theme);
        currTheme=sel;
        $scope.selected=index;        
        $scope.themes[currTheme].themeSelected =false;
        $scope.themes[sel].themeSelected =true;
        $scope.MessageType = $scope.themes[sel].theme;
        // $scope.MessageType = $scope.MessageType == $scope.themes[sel].theme ? "#fdd500" : $scope.themes[sel].theme;
        console.log($scope.MessageType);
    }   
    $scope.applyTheme = function() {
        console.log($scope.MessageType);
        $scope.defaultColor = $scope.MessageType;
        console.log($scope.defaultColor);
        $scope.IsVisible = $scope.IsVisible ? false : true;
    }
    $scope.cancelTheme = function() {
        
        $scope.IsVisible = $scope.IsVisible ? false : true;
    }
}

