import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-magicbox',
  templateUrl: './magicbox.component.html',
  styleUrls: ['./magicbox.component.css']
})
export class MagicboxComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
