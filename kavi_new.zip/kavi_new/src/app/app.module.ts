import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { Http, HttpModule } from "@angular/http";
import { RouterModule, Routes } from '@angular/router';
import { FormsModule } from '@angular/forms';

import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { CarouselConfig } from 'ngx-bootstrap/carousel';
import { CarouselModule } from 'ngx-bootstrap';

import { AppComponent } from './app.component';
import { ToyboxComponent } from './toybox/toybox.component';

import { MagicboxComponent } from './magicbox/magicbox.component';
import { ToolboxComponent } from './toolbox/toolbox.component';
import { ServiceboxComponent } from './servicebox/servicebox.component';
import { PageNotFoundComponent } from './page-not-found/page-not-found.component';
import { CategoryListComponent,SearchFilterPipe } from './toolbox/category-list/category-list.component';
import { PrototypeListComponent, CategoryPipe ,SearchFilterPipe2 } from './toolbox/prototype-list/prototype-list.component';
import { PrototypeItemComponent } from './toolbox/prototype-item/prototype-item.component';
import { PrototypeDetailComponent } from './toolbox/prototype-detail/prototype-detail.component';

import { CategoryService } from './shared/category.service';
import { PrototypeService } from './shared/prototype.service';
import { DataService } from './shared/data.service'; 
import { HeaderComponent } from './header/header.component';
import { FooterComponent } from './footer/footer.component';
import { ConceptBuilderComponent } from './magicbox/concept-builder/concept-builder.component';
import { ChatbotComponent } from './chatbot/chatbot.component';
// import { MessageItemDirective } from './chatbot/chatbot.component';
// import { ChatbotMessageComponent } from './chatbot-message/chatbot-message.component';

const appRoutes : Routes =[
  { 
    path : '', redirectTo : 'toybox', pathMatch : 'full'
  },
  { 
    path : 'toybox', component : ToyboxComponent
  },
  { 
    path : 'magicbox', component : MagicboxComponent, 
    children: [
    {
      path: '', component: ConceptBuilderComponent
    }]
  },
  { 
     path : 'toolbox', component:ToolboxComponent,
     children:[
        {
            path : '', component : CategoryListComponent          
        },
        {
            path : ':id', component : PrototypeListComponent
        },
        {
            path : ':id/:prototypeId', component : PrototypeDetailComponent
        }
      //{
      //    path : '', component : PrototypeListComponent
      //  },
       // {
        //    path : ':prototypeId', component : PrototypeDetailComponent
        // }
     ]
   },  
  { 
    path : 'servicebox', component : ServiceboxComponent,
    children: [
   
    ]
  },
  { 
    path : '**', component : PageNotFoundComponent
  }
]; 


@NgModule({
  declarations: [
    AppComponent, 
    HeaderComponent,
    FooterComponent,   
    ToyboxComponent,
    MagicboxComponent,
    ToolboxComponent,
    ServiceboxComponent,
    PageNotFoundComponent,
    CategoryListComponent,
    PrototypeListComponent,
    PrototypeItemComponent,
    PrototypeDetailComponent,
    CategoryPipe,
     SearchFilterPipe,
    SearchFilterPipe2,
    ConceptBuilderComponent,
    ChatbotComponent,
    // ChatbotMessageComponent,
    //  MessageItemDirective
   
    
  ],
  imports: [
    BrowserModule,
    HttpModule,
    FormsModule,

    RouterModule.forRoot(
      appRoutes,
      
    ),
    NgbModule.forRoot(),
    CarouselModule.forRoot()
  ],
  providers: [CategoryService, PrototypeService, DataService],
  bootstrap: [AppComponent]
})
export class AppModule { }
