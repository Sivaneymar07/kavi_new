var express = require('express');
var app = express();
var bodyParser = require('body-parser');
var request = require('request');
var userData = [];
var serverData = [];
var LineBreaker = require('linebreak');
const uuidv1 = require('uuid/v1');
 var reqID = uuidv1();

app.use(bodyParser.urlencoded({extended:false}));
app.use(bodyParser.json());

app.use(express.static(__dirname));
app.get('/', function(req, res) {
  res.sendFile('/index.html', { root: __dirname });
});

app.post('/msg', function(req,res){
    console.log(req.body);
   var data = {};
    var data = {
        "query": req.body.message,
        "lang": "en",
        "sessionId": reqID
    }
    request({
        url:"https://api.api.ai/v1/query?v=20150910",
        method:"POST",
        headers: {
            "Authorization": "Bearer 80522592a74649e4bb83c680959ce4bb",
            "content-type": "application/json"
        },
        body: JSON.stringify(data),
    }, function(error, response, body) {
        var newData = JSON.parse(body);
        var data = {};
        res.json(newData);
    });
});


