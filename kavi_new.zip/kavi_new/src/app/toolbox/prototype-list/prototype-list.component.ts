import { Component, OnInit, OnDestroy } from '@angular/core';
import { PrototypeService } from '../../shared/prototype.service';
import { Subscription } from 'rxjs/Rx';
import { ActivatedRoute, Router } from "@angular/router";
import { DataService } from '../../shared/data.service';
import { Pipe, PipeTransform } from "@angular/core";


@Component({
  selector: 'app-prototype-list',
  templateUrl: './prototype-list.component.html',
  styleUrls: ['./prototype-list.component.css']
})
export  class PrototypeListComponent implements OnInit, OnDestroy {

  prototypes=[];
  public domainNames:any[]=[];
  errorMessage='';
  prototypeSubscription:Subscription;
  prototypeFileName="";
  chatBotClick = false;
  detailsLength=0;
  public domainFilter = "";
  message: string;

  constructor(private prototypeService: PrototypeService, private route:ActivatedRoute, private router:Router,private data: DataService) {
   this.route.params.subscribe(
      (params) => {
        this.prototypeFileName=params['id'];
      });
   }

  ngOnInit() {   
    this.prototypeService.loadPrototypes(this.prototypeFileName);
    this.prototypeSubscription = this.prototypeService.prototypeSubject.subscribe(
      (prototypes) => {
          this.prototypes= prototypes;
        
             for(let i in this.prototypes){
    
      this.domainNames.push(this.prototypes[i].industry)
    }
    let a= this.domainNames;

    this.domainNames = a.filter(function(item,pos){
      return a.indexOf(item) == pos;
    })
      }

    )
    this.data.currentMessage.subscribe(message => this.message = message);
  }

  onPrototypeClick(prototypeId){
    
    this.router.navigate([prototypeId], {relativeTo:this.route})
  }

   ngOnDestroy(){
    this.prototypeSubscription.unsubscribe();
  }

  gotoPrototypeDetail(prototypeId){
    this.router.navigate([prototypeId], {relativeTo:this.route})
  }

  backToCategoryList(){
    this.router.navigate(['../'], {relativeTo:this.route})
  }
  

}

@Pipe({
  name: 'categoryPipe'
})
export class CategoryPipe implements PipeTransform {
  transform(arr:any, filterId:any, domainFilter: any): any{
    console.log(filterId);
  let tempArr = arr.filter(function(item){
    return item.accronym == filterId;
  });
  if(domainFilter != ""){
    tempArr = tempArr.filter(function(item){
      return (item.industry == domainFilter)
    })
  }
  let length = tempArr.length;
  console.log(length)
  return tempArr;
}
  }


@Pipe({
 name: 'searchfilter2'
})
export class SearchFilterPipe2 implements PipeTransform {
 transform(prototypes: any, search: string, keyToSearch:string): any {
  
  if(search === undefined) {
    return prototypes;
  }
  return prototypes.filter(function(prototype){
    return prototype[keyToSearch].toLowerCase().includes(search.toLowerCase());
  })

 }
}