
angular.module('ToyBox.gotoController',[])
    .controller("gotoController",gotoController);

 	function gotoController($scope,$location){
 		$scope.gotoConcept = function(){
 			$location.path('/conceptBuilder'); 
 		}	
         $scope.gotoChannel = function(){
 			$location.path('/channel'); 
 		}	
		 $scope.gotoNature = function(){
 			$location.path('/natureOfWebsite'); 
 		}
	}	

 	gotoController.$inject = ['$scope','$location'];

	 