import { Component, OnInit, OnDestroy } from '@angular/core';
import { CategoryService } from '../../shared/category.service';
import { Subscription } from 'rxjs/Rx';
import { ActivatedRoute, Router } from "@angular/router";
import { DataService } from '../../shared/data.service';
import { Pipe, PipeTransform } from '@angular/core'; 



@Component({
  selector: 'app-category-list',
  templateUrl: './category-list.component.html',
  styleUrls: ['./category-list.component.css']
})
export class CategoryListComponent implements OnInit , OnDestroy {

  categories=[];
  errorMessage='';
  message: string;
  categorySubscription:Subscription;

  constructor(private categoryService: CategoryService, private route:ActivatedRoute, private router:Router,private data: DataService) { }

  ngOnInit() {
    this.categorySubscription = this.categoryService.getCategories().subscribe(
      (response) => {
        console.log(response);
        this.categories = this.customSlice(response.category);      
      },
      (error)=>{
        this.errorMessage=error;
        console.log("Error : "+error)
      }
    )
     this.data.currentMessage.subscribe(message => this.message = message)
  }
  
  customSlice(data){
    let newArr = [];
    if(data.length > 4){
      let originalDataLength  = Math.ceil(data.length / 4);
      let StartingIndex = 0;
      while(originalDataLength > 0) {
        newArr.push(data.slice(StartingIndex,StartingIndex+4));
        StartingIndex += 4;
        originalDataLength--;
      }
      return newArr;
    }else{
      return data;
    }
  }
  onCategoryClick(id){
    this.router.navigate([id], {relativeTo:this.route})
  }
  

  ngOnDestroy(){
    this.categorySubscription.unsubscribe();
  }
}

@Pipe({
 name: 'searchfilter'
})
export class SearchFilterPipe implements PipeTransform {
 transform(item: any, search: string, name:string): any {
  
  if(search === undefined) {
    return item;
  }
  return item.filter(function(category){
    return category.name.toLowerCase().includes(search.toLowerCase());
  })

 }
} 
