angular.module('ToyBox.repoController',[])
	    .controller("repoController",repoController);

    function repoController($scope,$location,libraryFactory){
        $scope.gotoLibrary = function(){
 			$location.path('/library'); 
 		}	
    }
repoController.$inject = ['$scope','$location'];